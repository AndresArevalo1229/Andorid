package com.example.proyecto

data class Usuarios(
    var correo:String,
    var contra:String,
    var identidad:String,
    var moderador:String,
    var photo:String

)