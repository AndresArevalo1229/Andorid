package com.example.proyecto


data class Productos(
    var Nombre:String,
    var precio:Double,
    var existencias:Int,
    var photo:String
)