package com.example.proyecto

data class Carrito(
    var Nombre:String,
    var cantidad:Int,
    var precioTotal:Double,
    var Persona:String,
    var photo:String
)
